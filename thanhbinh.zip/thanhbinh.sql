/*
 Navicat Premium Data Transfer

 Source Server         : laravel_wise
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : thanhbinh

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 13/06/2021 19:14:32
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `slug` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `thumbnail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `meta_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `meta_desc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `status` enum('active','disable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `lang_code` enum('vn','en') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'vn',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES (1, 'Tin tức sự kiện', 'tin-tuc-su-kien', 0, 'Chuyên mục tin tức sự kiện tại website', NULL, 4, 'Tin tức sự kiện', 'Chuyên mục tin tức sự kiện tại website', 'active', 'vn', '2021-05-20 18:33:14', '2021-05-22 11:19:12');
INSERT INTO `category` VALUES (2, 'Tuyển dụng', 'tuyen-dung', 0, 'Chuyên mục tin tuyển dụng', NULL, 2, 'Tuyển dụng', 'Chuyên mục tin tuyển dụng', 'active', 'vn', '2021-05-20 18:35:07', '2021-05-22 11:18:52');
INSERT INTO `category` VALUES (3, 'Giới thiệu chung', 'gioi-thieu-chung', 0, 'Giới thiệu về danh mục', NULL, 2, 'Giới thiệu chung', 'Giới thiệu về danh mục', 'active', 'vn', '2021-05-21 09:35:38', '2021-05-22 11:18:49');
INSERT INTO `category` VALUES (4, 'Về chúng tôi', 've-chung-toi', 3, NULL, NULL, 1, 'Về chúng tôi', NULL, 'active', 'vn', '2021-05-21 09:36:04', '2021-05-22 11:18:45');
INSERT INTO `category` VALUES (5, 'Tầm nhìn sứ mệnh', 'tam-nhin-su-menh', 3, NULL, NULL, 2, 'Tầm nhìn sứ mệnh', NULL, 'active', 'vn', '2021-05-21 09:36:43', '2021-05-22 11:18:41');
INSERT INTO `category` VALUES (6, 'Giá trị cốt lõi', 'gia-tri-cot-loi', 3, NULL, NULL, 1, 'Giá trị cốt lõi', NULL, 'active', 'vn', '2021-05-21 12:43:37', '2021-05-22 11:18:31');
INSERT INTO `category` VALUES (7, 'Products', 'products', 0, NULL, NULL, 1, 'Products', NULL, 'active', 'en', '2021-05-24 10:40:30', '2021-05-24 10:40:30');
INSERT INTO `category` VALUES (8, 'News and event', 'news-and-event', 0, NULL, NULL, 2, 'News and event', NULL, 'active', 'en', '2021-05-24 10:40:48', '2021-05-24 10:40:48');

-- ----------------------------
-- Table structure for catproduct
-- ----------------------------
DROP TABLE IF EXISTS `catproduct`;
CREATE TABLE `catproduct`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `thumbnail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `meta_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `meta_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` enum('active','disable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `lang_code` enum('vn','en') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'vn',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of catproduct
-- ----------------------------
INSERT INTO `catproduct` VALUES (1, 'Cà phê', 'ca-phe', 0, NULL, 'Xuât khẩu Cà phê tại Việt Nam', 'Cà phê Việt Nam được biết đến là một trong những thương hiệu cà phê có tiếng trên thị trường thế giới, đây là một trong mặt hàng xuất khẩu chủ lực của nước ta trong những năm qua. Hàng năm, kim ngạch xuất khẩu cà phê luôn tăng cho thấy những dấu hiệu tốt về thị trường của cà phê vẫn được mọi người đón nhận.', 3, 'active', 'vn', '2021-05-24 12:43:38', '2021-05-31 15:13:01');
INSERT INTO `catproduct` VALUES (2, 'Cao su', 'cao-su', 0, NULL, 'Xuất khẩu Cao su tại việt nam', 'Cao su của Việt Nam được xuất chủ yếu sang thị trường Trung Quốc, các nước EU, Ấn Độ và Đông Nam Á, trong đó Trung Quốc là thị trường có lượng cao su xuất khẩu nhiều nhất, chiếm 64,84% tổng lượng xuất khẩu đạt 623,91 nghìn tấn, trị giá 842,94 triệu USD, tăng 11,30% về lượng và 9,47% trị giá, giá xuất trung bình 1351,05 USD/tấn, giảm 1,64% so với cùng kỳ năm 2018.', 2, 'active', 'vn', '2021-05-24 12:46:50', '2021-05-31 15:12:33');
INSERT INTO `catproduct` VALUES (3, 'Gỗ và các sản phẩm về gỗ', 'go-va-cac-san-pham-ve-go', 0, NULL, 'Gỗ và các sản phẩm về gỗ tại Việt Nam', 'Hiện Việt Nam đã trở thành trung tâm chế biến gỗ của Châu Á. Xuất khẩu và mở rộng xuất khẩu gỗ và các sản phẩm gỗ của Việt Nam có vai trò rất lớn của nguồn nguyên liệu gỗ nhập khẩu.', 1, 'active', 'vn', '2021-05-24 12:54:50', '2021-05-31 15:12:00');
INSERT INTO `catproduct` VALUES (4, 'Hàng thủy sản', 'hang-thuy-san', 0, NULL, 'Hàng thủy sản tại Việt Nam', 'Thủy sản là một trong những mặt hàng nông sản được xuất khẩu nhiều từ Việt Nam, mặt hàng này được xuất khẩu và được đón nhận ở nhiều quốc gia phát triển. Trong đó, Hoa Kỳ là thị trường xuất khẩu thủy sản lớn nhất của Việt Nam chiếm gần 30% kim ngạch xuất khẩu hàng thủy sản của nước ta, tiếp đó là đến thị trường các nước EU và thị trường Nhật Bản. Việt Nam rất chú trọng về việc xuất khẩu mặt hàng này, luôn có những đầu tư và chính sách hỗ trợ cho quá trình xuất khẩu được diễn ra thuận lợi. Hàng năm, số lượng mặt hàng này xuất khẩu ra thị trường rất lớn nhưng cũng đặt ra nhiều vấn đề khi mặt hàng này có mặt trên thị trường thế giới.', 4, 'active', 'vn', '2021-05-25 17:37:29', '2021-05-31 15:13:25');
INSERT INTO `catproduct` VALUES (5, 'Giày dép các loại', 'giay-dep-cac-loai', 0, NULL, 'Giày dép các loại tại Việt Nam', 'Giày dép các loại là một trong số những mặt hàng xuất khẩu lớn tại Việt Nam, nhóm hàng này chủ yếu được xuất khẩu ra các thị trường như EU, Hoa Kỳ, và cũng không tránh khỏi xu thế chung thì khối doanh nghiệp FDI xuất khẩu mặt hàng này chiếm tỷ lệ lớn trong kim ngạch xuất khẩu cả nước. Những mặt hàng thuộc nhóm này đều có chất lượng tương đối tốt, tuy nhiên thị trường ở trong nước lại không nhiều nên chủ yếu được xuất khẩu.', 5, 'active', 'vn', '2021-05-25 17:37:42', '2021-05-31 15:13:49');
INSERT INTO `catproduct` VALUES (6, 'Hàng dệt may', 'hang-det-may', 0, NULL, 'Hàng dệt may tại Việt Nam', 'Hàng dệt may là một trong những mặt hàng dẫn đầu về kim ngạch xuất khẩu trong suốt thời gian qua. Và cũng giống như các mặt hàng linh kiện điện tử thì hàng dệt may cũng chủ yếu được xuất khẩu từ các công ty có vốn đầu tư nước ngoài (tính đến năm 2016 có đến hơn 60% kim ngạch xuất khẩu là hàng hóa thuộc công ty có vốn đầu tư trực tiếp nước ngoài). Các mặt hàng dệt may của Việt Nam vô cùng đa dạng và phong phú, nhất là các mặt hàng dệt may truyền thống, họa tiết và chất liệu được nhiều thị trường đón nhận.', 6, 'active', 'vn', '2021-05-25 17:37:52', '2021-05-31 15:14:09');
INSERT INTO `catproduct` VALUES (7, 'Sản phẩm khác', 'san-pham-khac', 0, NULL, 'Sản phẩm xuất khẩu tại Việt Nam', 'Các mặt hàng nghệ thuật, các sản phẩm liên quan đến tre', 7, 'active', 'vn', '2021-05-25 17:38:03', '2021-05-31 15:14:51');
INSERT INTO `catproduct` VALUES (16, 'Wood and wood products', 'wood-and-wood-products', 0, NULL, 'Wood and wood products in Viet Nam', 'Currently, Vietnam has become the wood processing center of Asia. Export and expansion of Vietnam\'s wood and wood products exports play a huge role in the source of imported wood materials.', 1, 'active', 'en', '2021-05-25 17:41:59', '2021-05-31 15:07:47');
INSERT INTO `catproduct` VALUES (17, 'The coffee', 'the-coffee', 0, NULL, 'The coffee in Viet Nam', 'Vietnamese coffee is known as one of the famous coffee brands in the world market, this is one of the main export items of Vietnam in recent years. Every year, coffee export turnover is always increasing, showing that the good signs about the coffee market are still well received by everyone.', 2, 'active', 'en', '2021-05-25 17:42:53', '2021-05-31 15:04:08');
INSERT INTO `catproduct` VALUES (18, 'Seafood', 'seafood', 0, NULL, 'Seafood in Viet Nam', 'Seafood is one of the agricultural products that are exported a lot from Vietnam, this item is exported and well received in many developed countries. In which, the United States is Vietnam\'s largest seafood export market, accounting for nearly 30% of our country\'s seafood export turnover, followed by EU countries and Japan. Vietnam pays great attention to the export of this item, always has investments and policies to support the export process smoothly. Every year, the number of these items exported to the market is very large, but it also poses many problems when this item is available on the world market.', 3, 'active', 'en', '2021-05-25 17:43:34', '2021-05-31 15:02:46');
INSERT INTO `catproduct` VALUES (19, 'Footwear', 'footwear', 0, NULL, 'Footwear in Viet Nam', 'Footwear of all kinds is one of the major export items in Vietnam, this group of goods is mainly exported to markets such as the EU and the United States, and it is inevitable that the FDI enterprises Exports of this item account for a large proportion of the country\'s export turnover. The products of this group are of relatively good quality, but the domestic market is not much, so they are mainly exported.', 4, 'active', 'en', '2021-05-25 17:43:56', '2021-05-31 15:03:07');
INSERT INTO `catproduct` VALUES (20, 'Garment', 'garment', 0, NULL, 'Garment Factory In Viet Nam', 'Garment is one of the top exporters in terms of export turnover during the past time', 5, 'active', 'en', '2021-05-25 17:44:32', '2021-05-31 15:02:57');
INSERT INTO `catproduct` VALUES (21, 'Rubber', 'rubber', 0, NULL, 'The Rubber in Viet Nam', 'Vietnam\'s rubber is mainly exported to China, EU countries, India and Southeast Asia, of which China is the market with the largest amount of rubber exports, accounting for 64.84% of the total export volume. exports reached 623.91 thousand tons, valued at USD 842.94 million, up 11.30% in volume and 9.47% in value, the average export price was USD 1351.05/ton, down 1.64% over the same period. term 2018.', 6, 'active', 'en', '2021-05-31 15:08:38', '2021-05-31 15:15:49');
INSERT INTO `catproduct` VALUES (22, 'Other items', 'other-items', 0, NULL, 'Other items in Việt Nam', 'art products, bamboo-related products', 7, 'active', 'en', '2021-05-31 15:10:31', '2021-05-31 15:15:50');

-- ----------------------------
-- Table structure for catproduct_company
-- ----------------------------
DROP TABLE IF EXISTS `catproduct_company`;
CREATE TABLE `catproduct_company`  (
  `company_id` int(10) UNSIGNED NOT NULL,
  `cat_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`company_id`, `cat_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of catproduct_company
-- ----------------------------
INSERT INTO `catproduct_company` VALUES (1, 3);
INSERT INTO `catproduct_company` VALUES (1, 4);
INSERT INTO `catproduct_company` VALUES (3, 1);
INSERT INTO `catproduct_company` VALUES (3, 6);
INSERT INTO `catproduct_company` VALUES (4, 1);
INSERT INTO `catproduct_company` VALUES (4, 3);
INSERT INTO `catproduct_company` VALUES (4, 8);
INSERT INTO `catproduct_company` VALUES (5, 22);

-- ----------------------------
-- Table structure for company
-- ----------------------------
DROP TABLE IF EXISTS `company`;
CREATE TABLE `company`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `tax_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `moneyrule` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `operating_year` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `legal_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `thumbnail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `meta_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `meta_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `useradd` int(10) NULL DEFAULT 0,
  `count_view` int(10) NULL DEFAULT 0,
  `display` int(11) NOT NULL DEFAULT 0,
  `operating_status` enum('active','disable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `status` enum('active','disable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `lang_code` enum('vn','en') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'vn',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of company
-- ----------------------------
INSERT INTO `company` VALUES (1, 'Công ty cổ phần liên kết số tda', 'cong-ty-co-phan-lien-ket-so-tda', '0106120466', '2 tỷ đồng', '2013', '1', 'Hà Nội', 'Số 9, ngách 59/21, đường Mễ Trì, Phường Mễ Trì, Quận Nam Từ Liêm, Thành phố Hà Nội, Việt Nam', '0978823452', 'thanhan1507@gmail.com', 'Bán lẻ máy vi tính, thiết bị ngoại vi, phần mềm và thiết bị viễn thông trong các cửa hàng chuyên doanh, Lập trình máy vi tính, Hoạt động dịch vụ công nghệ thông tin và dịch vụ khác liên quan đến máy vi tính, Xử lý dữ liệu, cho thuê và các hoạt động liên quan', '<p>Ch&uacute;ng t&ocirc;i l&agrave;m website kh&ocirc;ng chỉ đơn giản l&agrave; l&agrave;m ra một sản phẩm, m&agrave; đ&oacute; c&ograve;n l&agrave; một giải ph&aacute;p trong việc kết nối doanh nghiệp với kh&aacute;ch h&agrave;ng, bởi vậy ch&uacute;ng t&ocirc;i sẽ đồng h&agrave;nh c&ugrave;ng bạn tr&ecirc;n con đường ph&aacute;t triển sau n&agrave;y.</p>\r\n\r\n<p>Trong thế giới kỹ thuật số ng&agrave;y nay, trang web của bạn l&agrave; nơi tương t&aacute;c đầu ti&ecirc;n giữa người ti&ecirc;u d&ugrave;ng c&oacute; với doanh nghiệp của bạn.</p>\r\n\r\n<p>Đ&oacute; l&agrave; l&yacute; do tại sao gần 95% ấn tượng đầu ti&ecirc;n của người d&ugrave;ng li&ecirc;n quan đến thiết kế web . Đ&oacute; cũng l&agrave; l&yacute; do tại sao c&aacute;c dịch vụ thiết kế web c&oacute; thể c&oacute; t&aacute;c động to lớn đến lợi nhuận của c&ocirc;ng ty bạn. Ch&iacute;nh v&igrave; vậy, việc c&oacute; một trang web hấp dẫn cả về mặt h&igrave;nh ảnh, bố cục v&agrave; nội dung l&agrave; điều đầu ti&ecirc;n tạo cho kh&aacute;ch h&agrave;ng của bạn cảm gi&aacute;c muốn được l&agrave;m việc với doanh nghiệp. Với hơn 6 năm kinh nghiệm, ch&uacute;ng t&ocirc;i tự tin c&oacute; thể thiết kế một trang web t&ugrave;y chỉnh th&uacute;c đẩy doanh số b&aacute;n h&agrave;ng cho doanh nghiệp của bạn.</p>', '2021/05/25/1621936972-logo-lks.png', 'CÔNG TY CỔ PHẦN LIÊN KẾT SỐ TDA', 'Bán lẻ máy vi tính, thiết bị ngoại vi, phần mềm và thiết bị viễn thông trong các cửa hàng chuyên doanh, Lập trình máy vi tính, Hoạt động dịch vụ công nghệ thông tin và dịch vụ khác liên quan đến máy vi tính, Xử lý dữ liệu, cho thuê và các hoạt động liên quan', 14, 9, 1, 'active', 'active', 'vn', '2021-05-25 17:02:52', '2021-05-31 12:54:02');
INSERT INTO `company` VALUES (2, 'TDA DIGITAL LINKS JOINT STOCK COMPANY', 'tda-digital-links-joint-stock-company', '0106120466', '1 million dollars', '2013', '1', 'Ha Noi City', 'No. 9, alley 59/21, Me Tri Street, Me Tri Ward, Nam Tu Liem District, Hanoi City, Vietnam', '+84978823452', 'thanhan1507@gmail.com', 'Retail sale of computers, peripheral equipment, software and telecommunications equipment in specialized stores, Computer programming, Information technology service activities and other computer-related services, Data processing, leasing and related activities', '<p>In today&#39;s digital world, your website is the first interaction a consumer has with your business.</p>\r\n\r\n<p>That&#39;s why almost 95% of users&#39; first impressions are related to web design. That&#39;s also why web design services can have a huge impact on your company&#39;s bottom line.</p>\r\n\r\n<p>Therefore, having an attractive website in terms of images, layout and content is the first thing that gives your customers the feeling of wanting to work with your business. With over 6 years of experience, we can confidently design a custom website that drives sales for your business.</p>', '2021/05/25/1621938721-logo-lks.png', 'TDA DIGITAL LINKS JOINT STOCK COMPANY', 'Retail sale of computers, peripheral equipment, software and telecommunications equipment in specialized stores, Computer programming, Information technology service activities and other computer-related services, Data processing, leasing and related activities', 14, 2, 1, 'active', 'active', 'en', '2021-05-25 17:32:01', '2021-05-31 15:51:49');
INSERT INTO `company` VALUES (3, 'Công ty tnhh thương mại toàn cầu đức chính', 'cong-ty-tnhh-thuong-mai-toan-cau-duc-chinh', NULL, '2 tỷ đồng', '2013', '1', 'Hà Nội', 'Số 36, ngõ 86, phố Hào Nam, phường Ô Chợ Dừa, Quận Đống Đa, Thành Phố Hà Nội', '0913099933', 'doanhvhai@gmail.com', NULL, NULL, NULL, 'CÔNG TY TNHH THƯƠNG MẠI TOÀN CẦU ĐỨC CHÍNH', NULL, 14, 8, 1, 'active', 'active', 'vn', '2021-05-25 19:09:32', '2021-05-29 18:27:23');
INSERT INTO `company` VALUES (4, 'Công ty cổ phần powder metal việt nam', 'cong-ty-co-phan-powder-metal-viet-nam', NULL, '2 tỷ đồng', '2013', '1', 'Hà Nội', 'Số 02A đường 3.7/9, Khu đô thị Gamuda, Phường Yên Sở, Quận Hoàng Mai, Thành phố Hà Nội, Việt Nam', '0916995658', 'Powdermetall.jsc@gmail.com', NULL, NULL, NULL, 'CÔNG TY CP POWDER METALL VIỆT NAM', NULL, 14, 10, 2, 'active', 'active', 'vn', '2021-05-25 19:11:29', '2021-05-31 14:50:45');
INSERT INTO `company` VALUES (5, 'Bamboo vina company limited', 'bamboo-vina-company-limited', NULL, NULL, NULL, '1', 'Thanh Hoa', 'Dong Ninh, Yen Son, Ha Trung, Thanh Hoa', '+84 948 428 438', 'vnvansantre@gmail.com', 'From a factory that only manufactures to order with more than 20 employees, until now, after nearly 5 years of development, we have a team of officers, employees, technicians - designers up to above 100 people with high technical skills, advanced machinery, produce products that meet export standards.', '<p>BAMBOO VINA BAMBOO PLANTS AND HOME FURNITURE FACTORY</p>\r\n\r\n<p>From a factory that only manufactures to order with more than 20 employees, until now, after nearly 5 years of development, we have a team of officers, employees, technicians - designers up to above 100 people with high technical skills, advanced machinery, produce products that meet export standards.</p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://hmvc.test/upload/2021/05/31/banner-top_1622449286.png\" style=\"height:344px; width:800px\" /></p>\r\n\r\n<p>With the goal of a strong and comprehensive transformation from production of raw materials to order to mass industrial production, creating high-quality and high-value finished home and interior products, the Factory has invest and upgrade many types of modern and advanced machinery with the scale and production of thousands of products per day.</p>', '2021/05/31/1622449219-logo_bamboo.png', 'Bamboo vina company limited', 'From a factory that only manufactures to order with more than 20 employees, until now, after nearly 5 years of development, we have a team of officers, employees, technicians - designers up to above 100 people with high technical skills, advanced machinery, produce products that meet export standards.', 14, 26, 1, 'active', 'active', 'en', '2021-05-31 15:20:19', '2021-05-31 17:28:26');

-- ----------------------------
-- Table structure for contact
-- ----------------------------
DROP TABLE IF EXISTS `contact`;
CREATE TABLE `contact`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `messenger` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `status` enum('active','disable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'disable',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of contact
-- ----------------------------
INSERT INTO `contact` VALUES (1, 'Nguyễn Thành An', '0979823452', 'Thái Nguyên', 'thanhan1507@gmail.com', 'Tôi cần tư vấn', 'Tư vấn về dịch vụ sửa chữa website', 'active', '2021-05-23 16:26:49', '2021-05-24 08:50:02');
INSERT INTO `contact` VALUES (2, 'Nguyễn Hà My', '0900888999', 'Hà Nội', 'hamy@gmail.com', 'thử test xem sao', 'Tôi cần test dữ liệu', 'disable', '2021-05-23 16:33:44', '2021-05-23 17:15:53');
INSERT INTO `contact` VALUES (3, 'Nguyễn Thành An', NULL, NULL, 'annt@lienketso.vn', 'Tôi đang test thử contact', 'bạn cần tôi hỗ trợ gì không hehe', 'disable', '2021-05-29 15:30:31', '2021-05-29 15:30:31');
INSERT INTO `contact` VALUES (4, 'Nguyễn Thành An', NULL, NULL, 'annt@lienketso.vn', 'Tôi đang test thử contact', 'bạn cần tôi hỗ trợ gì không hehe', 'disable', '2021-05-29 15:31:05', '2021-05-29 15:31:05');
INSERT INTO `contact` VALUES (5, 'Vũ Văn Hải', NULL, NULL, 'doanhvhai@gmail.com', 'Hỗ trợ chuyển đổi dữ liệu email', NULL, 'active', '2021-05-29 15:31:19', '2021-05-31 17:21:08');
INSERT INTO `contact` VALUES (6, 'Vũ Văn Hải', NULL, NULL, 'doanhvhai@gmail.com', 'Hỗ trợ chuyển đổi dữ liệu email', NULL, 'disable', '2021-05-29 15:31:38', '2021-05-29 15:31:38');
INSERT INTO `contact` VALUES (7, 'Vũ Văn Hải', NULL, NULL, 'doanhvhai@gmail.com', 'Hỗ trợ chuyển đổi dữ liệu email', NULL, 'active', '2021-05-29 15:38:16', '2021-05-31 17:21:20');

-- ----------------------------
-- Table structure for failed_jobs
-- ----------------------------
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of failed_jobs
-- ----------------------------

-- ----------------------------
-- Table structure for gallery
-- ----------------------------
DROP TABLE IF EXISTS `gallery`;
CREATE TABLE `gallery`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `thumbnail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `link` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `lang_code` enum('vn','en') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'vn',
  `status` enum('active','disable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of gallery
-- ----------------------------

-- ----------------------------
-- Table structure for gallery_group
-- ----------------------------
DROP TABLE IF EXISTS `gallery_group`;
CREATE TABLE `gallery_group`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `lang_code` enum('vn','en') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'vn',
  `status` enum('active','disable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of gallery_group
-- ----------------------------
INSERT INTO `gallery_group` VALUES (1, 'Slider', 'Thư viện ảnh slider top trang web', 'vn', 'active', '2021-06-13 18:09:19', '2021-06-13 18:09:20');

-- ----------------------------
-- Table structure for media
-- ----------------------------
DROP TABLE IF EXISTS `media`;
CREATE TABLE `media`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `table` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `table_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `original_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `path_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of media
-- ----------------------------
INSERT INTO `media` VALUES (13, 'product', 2, '2021/05/24/dssds.jpg', 'dssds.jpg', 'upload/2021/05/24/dssds.jpg', '2021-05-24 18:48:39', '2021-05-24 18:48:39');
INSERT INTO `media` VALUES (27, 'product', 4, '2021/05/25/1621913565-trung-nuong-pmg.png', '2021/05/25/trứng nướng pmg.png', 'upload/2021/05/25/1621913565-trung-nuong-pmg.png', '2021-05-25 10:32:45', '2021-05-25 10:32:45');
INSERT INTO `media` VALUES (28, 'product', 3, '2021/05/25/1621913651-trung-nuong-pmg.png', '2021/05/25/trứng nướng pmg.png', 'upload/2021/05/25/1621913651-trung-nuong-pmg.png', '2021-05-25 10:34:11', '2021-05-25 10:34:11');

-- ----------------------------
-- Table structure for menu
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `link` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` enum('active','disable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `lang_code` enum('vn','en') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'vn',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES (1, 'Trang chủ', 0, NULL, 'link', 1, 'active', 'vn', '2021-05-21 18:01:05', '2021-05-21 18:01:05');
INSERT INTO `menu` VALUES (2, 'Giới thiệu', 0, NULL, 'blog', 2, 'active', 'vn', '2021-05-21 18:07:35', '2021-05-21 18:07:35');
INSERT INTO `menu` VALUES (3, 'Giới thiệu chung', 2, 'http://hmvc.test/page/gioi-thieu-ve-lien-ket-so', 'page', 1, 'active', 'vn', NULL, '2021-05-31 13:29:27');
INSERT INTO `menu` VALUES (4, 'Tin tức sự kiện', 0, NULL, 'blog', 3, 'active', 'vn', NULL, NULL);
INSERT INTO `menu` VALUES (9, 'Liên hệ', 0, 'contact', 'link', 4, 'active', 'vn', '2021-05-22 11:02:07', '2021-05-23 13:54:40');
INSERT INTO `menu` VALUES (10, 'Tầm nhìn sứ mệnh', 2, 'blog/tam-nhin-su-menh', 'blog', 5, 'active', 'vn', '2021-05-23 10:50:31', '2021-05-25 15:00:55');
INSERT INTO `menu` VALUES (11, 'Danh sách công ty', 0, 'company', 'link', 2, 'active', 'vn', '2021-05-23 12:55:09', '2021-05-27 17:20:40');
INSERT INTO `menu` VALUES (12, 'Home', 0, 'index.html', 'link', 0, 'active', 'en', '2021-05-24 09:44:13', '2021-05-24 09:44:13');
INSERT INTO `menu` VALUES (13, 'Contact', 0, 'contact.html', 'link', 7, 'active', 'en', '2021-05-24 09:45:39', '2021-05-29 09:56:38');
INSERT INTO `menu` VALUES (14, 'Companies list', 0, 'company', 'link', 3, 'active', 'en', '2021-05-29 09:55:25', '2021-05-29 09:55:25');
INSERT INTO `menu` VALUES (15, 'Categories', 0, 'category', 'link', 4, 'active', 'en', '2021-05-29 09:56:30', '2021-05-29 09:56:30');
INSERT INTO `menu` VALUES (16, 'News and event', 0, 'blog/news-and-event', 'blog', 5, 'active', 'en', '2021-05-29 09:57:03', '2021-05-29 09:57:03');

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of migrations
-- ----------------------------
INSERT INTO `migrations` VALUES (1, '2014_10_12_100000_create_password_resets_table', 1);
INSERT INTO `migrations` VALUES (2, '2019_08_19_000000_create_failed_jobs_table', 1);
INSERT INTO `migrations` VALUES (3, '2020_11_14_095133_create_users_table', 1);
INSERT INTO `migrations` VALUES (4, '2021_05_18_133016_create_acl_table', 2);
INSERT INTO `migrations` VALUES (5, '2021_05_20_140924_create_post_table', 3);
INSERT INTO `migrations` VALUES (6, '2021_05_20_175855_create_category_table', 4);
INSERT INTO `migrations` VALUES (7, '2021_05_21_173602_create_menu_table', 5);
INSERT INTO `migrations` VALUES (8, '2021_05_23_143622_create_setting_table', 6);
INSERT INTO `migrations` VALUES (9, '2021_05_23_162348_create_contact_table', 7);
INSERT INTO `migrations` VALUES (10, '2021_05_24_111353_create_product_table', 8);
INSERT INTO `migrations` VALUES (11, '2021_05_24_111430_create_catproduct_table', 8);
INSERT INTO `migrations` VALUES (12, '2021_05_24_160729_create_media_table', 9);
INSERT INTO `migrations` VALUES (13, '2021_05_25_152906_create_company_table', 10);
INSERT INTO `migrations` VALUES (16, '2021_05_25_174559_create_catproduct_company_table', 11);
INSERT INTO `migrations` VALUES (17, '2021_05_29_155252_create_newsletter_table', 12);
INSERT INTO `migrations` VALUES (18, '2021_05_31_105720_create_transaction_table', 13);
INSERT INTO `migrations` VALUES (19, '2021_06_13_172953_create_gallery_group_table', 14);
INSERT INTO `migrations` VALUES (20, '2021_06_13_173010_create_gallery_table', 14);

-- ----------------------------
-- Table structure for newsletter
-- ----------------------------
DROP TABLE IF EXISTS `newsletter`;
CREATE TABLE `newsletter`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of newsletter
-- ----------------------------
INSERT INTO `newsletter` VALUES (1, 'doanhvhai@gmail.com', '2021-05-29 16:42:50', '2021-05-29 16:42:50');
INSERT INTO `newsletter` VALUES (2, 'thanhan1507@gmail.com', '2021-05-29 16:42:59', '2021-05-29 16:42:59');
INSERT INTO `newsletter` VALUES (3, 'anhtt.kci@gmail.com.vn', '2021-05-29 16:43:28', '2021-05-29 16:43:28');

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets`  (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  INDEX `password_resets_email_index`(`email`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of password_resets
-- ----------------------------

-- ----------------------------
-- Table structure for permission_role
-- ----------------------------
DROP TABLE IF EXISTS `permission_role`;
CREATE TABLE `permission_role`  (
  `role_id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`role_id`, `permission_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of permission_role
-- ----------------------------
INSERT INTO `permission_role` VALUES (1, 1);
INSERT INTO `permission_role` VALUES (1, 2);
INSERT INTO `permission_role` VALUES (1, 3);
INSERT INTO `permission_role` VALUES (1, 4);
INSERT INTO `permission_role` VALUES (1, 5);
INSERT INTO `permission_role` VALUES (1, 6);
INSERT INTO `permission_role` VALUES (1, 7);
INSERT INTO `permission_role` VALUES (1, 8);
INSERT INTO `permission_role` VALUES (1, 9);
INSERT INTO `permission_role` VALUES (1, 10);
INSERT INTO `permission_role` VALUES (1, 11);
INSERT INTO `permission_role` VALUES (1, 12);
INSERT INTO `permission_role` VALUES (1, 13);
INSERT INTO `permission_role` VALUES (1, 14);
INSERT INTO `permission_role` VALUES (1, 15);
INSERT INTO `permission_role` VALUES (1, 16);
INSERT INTO `permission_role` VALUES (1, 17);
INSERT INTO `permission_role` VALUES (1, 18);
INSERT INTO `permission_role` VALUES (1, 19);
INSERT INTO `permission_role` VALUES (1, 20);
INSERT INTO `permission_role` VALUES (1, 21);
INSERT INTO `permission_role` VALUES (1, 22);
INSERT INTO `permission_role` VALUES (1, 23);
INSERT INTO `permission_role` VALUES (1, 24);
INSERT INTO `permission_role` VALUES (1, 25);
INSERT INTO `permission_role` VALUES (1, 26);
INSERT INTO `permission_role` VALUES (1, 27);
INSERT INTO `permission_role` VALUES (1, 28);
INSERT INTO `permission_role` VALUES (1, 29);
INSERT INTO `permission_role` VALUES (1, 30);
INSERT INTO `permission_role` VALUES (1, 31);
INSERT INTO `permission_role` VALUES (1, 32);
INSERT INTO `permission_role` VALUES (1, 33);
INSERT INTO `permission_role` VALUES (1, 34);
INSERT INTO `permission_role` VALUES (1, 35);
INSERT INTO `permission_role` VALUES (1, 36);
INSERT INTO `permission_role` VALUES (1, 37);
INSERT INTO `permission_role` VALUES (1, 38);
INSERT INTO `permission_role` VALUES (1, 39);
INSERT INTO `permission_role` VALUES (1, 40);
INSERT INTO `permission_role` VALUES (1, 41);
INSERT INTO `permission_role` VALUES (1, 42);
INSERT INTO `permission_role` VALUES (1, 43);
INSERT INTO `permission_role` VALUES (1, 44);
INSERT INTO `permission_role` VALUES (1, 45);
INSERT INTO `permission_role` VALUES (1, 46);
INSERT INTO `permission_role` VALUES (1, 47);
INSERT INTO `permission_role` VALUES (1, 48);
INSERT INTO `permission_role` VALUES (1, 49);
INSERT INTO `permission_role` VALUES (1, 50);
INSERT INTO `permission_role` VALUES (4, 1);
INSERT INTO `permission_role` VALUES (4, 2);
INSERT INTO `permission_role` VALUES (4, 3);

-- ----------------------------
-- Table structure for permissions
-- ----------------------------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `module` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `permissions_name_unique`(`name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 51 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of permissions
-- ----------------------------
INSERT INTO `permissions` VALUES (1, 'permission_index', 'Xem danh sách quyền', 'Xem danh sách các quyền trong hệ thống', 'Acl', '2021-05-18 14:35:10', '2021-05-18 14:35:10');
INSERT INTO `permissions` VALUES (2, 'role_delete', 'Xóa vai trò', 'Xóa vai trò', 'Acl', '2021-05-18 14:39:52', '2021-05-18 14:39:52');
INSERT INTO `permissions` VALUES (3, 'role_edit', 'Sửa vai trò', 'Sửa vai trò', 'Acl', '2021-05-18 14:40:17', '2021-05-18 14:40:17');
INSERT INTO `permissions` VALUES (4, 'role_create', 'Thêm vai trò mới', 'Thêm vai trò mới', 'Acl', '2021-05-18 14:40:43', '2021-05-18 14:40:43');
INSERT INTO `permissions` VALUES (5, 'role_index', 'Xem danh sách vai trò', 'Xem danh sách các vai trò trong hệ thống', 'Acl', '2021-05-18 14:42:46', '2021-05-18 14:42:46');
INSERT INTO `permissions` VALUES (6, 'access_dashboard', 'Truy cập quản trị', 'Truy cập quản trị', 'Acl', '2021-05-18 14:55:32', '2021-05-18 14:55:32');
INSERT INTO `permissions` VALUES (7, 'users_index', 'Xem danh sách user', 'Được phép thêm thông tin danh sách user', 'Users', '2021-05-18 17:16:27', '2021-05-18 17:16:27');
INSERT INTO `permissions` VALUES (8, 'users_create', 'Thêm mới thành viên', 'Quyền thêm mới thành viên', 'Users', '2021-05-20 13:06:35', '2021-05-20 13:06:35');
INSERT INTO `permissions` VALUES (9, 'users_edit', 'Quyền sửa thành viên', 'Cho phép sửa thành viên', 'Users', '2021-05-20 13:07:07', '2021-05-20 13:07:07');
INSERT INTO `permissions` VALUES (10, 'users_delete', 'Quyền xóa thành viên', 'Cho phép có thể xóa thành viên', 'Users', '2021-05-20 13:07:43', '2021-05-20 13:07:43');
INSERT INTO `permissions` VALUES (11, 'post_index', 'Xem danh sách bài viết', 'Quyền xem danh sách bài viết', 'Post', '2021-05-20 15:12:35', '2021-05-20 15:12:35');
INSERT INTO `permissions` VALUES (12, 'post_create', 'Thêm bài viết mới', 'Quyền thêm bài viết mới', 'Post', '2021-05-20 15:12:59', '2021-05-20 15:12:59');
INSERT INTO `permissions` VALUES (13, 'post_edit', 'Sửa bài viết', 'Quyền sửa bài viết', 'Post', '2021-05-20 15:13:27', '2021-05-20 15:13:27');
INSERT INTO `permissions` VALUES (14, 'post_delete', 'Xóa bài viết', 'Quyền xóa bài viết', 'Post', '2021-05-20 15:13:46', '2021-05-20 15:13:46');
INSERT INTO `permissions` VALUES (15, 'category_index', 'Xem danh sách danh mục', 'Xem danh sách danh mục bài viét', 'Category', '2021-05-20 18:21:57', '2021-05-20 18:21:57');
INSERT INTO `permissions` VALUES (16, 'category_create', 'Xem danh sách danh mục', 'Quyền thêm danh mục mới', 'Category', '2021-05-20 18:22:31', '2021-05-20 18:22:31');
INSERT INTO `permissions` VALUES (17, 'category_edit', 'Sửa danh mục', 'Cho phép sửa danh mục', 'Category', '2021-05-20 18:22:54', '2021-05-20 18:22:54');
INSERT INTO `permissions` VALUES (18, 'category_delete', 'Xóa danh mục', 'Cho phép xóa danh mục bài viết', 'Category', '2021-05-20 18:23:25', '2021-05-20 18:23:25');
INSERT INTO `permissions` VALUES (19, 'menu_index', 'Xem danh sách menu', NULL, 'Menu', '2021-05-21 17:45:55', '2021-05-21 17:47:20');
INSERT INTO `permissions` VALUES (20, 'menu_create', 'Thêm menu mới', NULL, 'Menu', '2021-05-21 17:46:12', '2021-05-21 17:46:51');
INSERT INTO `permissions` VALUES (21, 'menu_edit', 'Sửa menu', NULL, 'Menu', '2021-05-21 17:46:21', '2021-05-21 17:47:15');
INSERT INTO `permissions` VALUES (22, 'menu_delete', 'Xóa menu', NULL, 'Menu', '2021-05-21 17:46:38', '2021-05-21 17:47:09');
INSERT INTO `permissions` VALUES (23, 'page_index', 'Xem danh sách trang tĩnh', NULL, 'Page', '2021-05-23 11:13:00', '2021-05-23 11:13:00');
INSERT INTO `permissions` VALUES (24, 'page_create', 'Thêm trang tĩnh', NULL, 'Page', '2021-05-23 11:13:11', '2021-05-23 11:13:11');
INSERT INTO `permissions` VALUES (25, 'page_edit', 'Sửa trang tĩnh', NULL, 'Page', '2021-05-23 11:13:21', '2021-05-23 11:13:21');
INSERT INTO `permissions` VALUES (26, 'page_delete', 'Xóa trang tĩnh', NULL, 'Page', '2021-05-23 11:13:34', '2021-05-23 11:13:34');
INSERT INTO `permissions` VALUES (27, 'setting_index', 'Cấu hình website', 'Truy cập cấu hình thông tin website', 'Setting', '2021-05-23 14:44:40', '2021-05-23 14:44:40');
INSERT INTO `permissions` VALUES (28, 'contact_index', 'Xem thông tin liên hệ', NULL, 'Contact', '2021-05-23 16:27:28', '2021-05-23 16:27:28');
INSERT INTO `permissions` VALUES (29, 'contact_delete', 'Xóa liên hệ', 'Xóa thông tin liên hệ', 'Contact', '2021-05-23 16:32:41', '2021-05-23 16:32:41');
INSERT INTO `permissions` VALUES (30, 'cat_index', 'Xem danh sách danh mục sản phẩm', NULL, 'Cat', '2021-05-24 12:28:13', '2021-05-24 12:28:13');
INSERT INTO `permissions` VALUES (31, 'cat_create', 'Thêm danh sách danh mục sản phẩm', NULL, 'Cat', '2021-05-24 12:28:35', '2021-05-24 12:28:35');
INSERT INTO `permissions` VALUES (32, 'cat_edit', 'Sửa danh sách danh mục sản phẩm', NULL, 'Cat', '2021-05-24 12:28:49', '2021-05-24 12:28:49');
INSERT INTO `permissions` VALUES (33, 'cat_delete', 'Xóa danh mục sản phẩm', NULL, 'Cat', '2021-05-24 12:29:14', '2021-05-24 12:29:14');
INSERT INTO `permissions` VALUES (34, 'product_index', 'Xem danh sách sản phẩm', NULL, 'Product', '2021-05-24 13:56:55', '2021-05-24 13:56:55');
INSERT INTO `permissions` VALUES (35, 'product_edit', 'Sửa sản phẩm', NULL, 'Product', '2021-05-24 13:57:15', '2021-05-24 13:57:15');
INSERT INTO `permissions` VALUES (36, 'product_create', 'Thêm sản phẩm mới', NULL, 'Product', '2021-05-24 13:57:27', '2021-05-24 13:57:27');
INSERT INTO `permissions` VALUES (37, 'product_delete', 'Xóa sản phẩm', NULL, 'Product', '2021-05-24 13:57:41', '2021-05-24 13:57:41');
INSERT INTO `permissions` VALUES (38, 'company_index', 'Xem danh sách công ty', NULL, 'Company', '2021-05-25 16:19:09', '2021-05-25 16:19:09');
INSERT INTO `permissions` VALUES (39, 'company_create', 'Thêm thông tin công ty', NULL, 'Company', '2021-05-25 16:19:27', '2021-05-25 16:19:27');
INSERT INTO `permissions` VALUES (40, 'company_edit', 'Sửa thông tin công ty', NULL, 'Company', '2021-05-25 16:19:41', '2021-05-25 16:19:41');
INSERT INTO `permissions` VALUES (41, 'company_delete', 'Xóa thông tin công ty', NULL, 'Company', '2021-05-25 16:19:56', '2021-05-25 16:19:56');
INSERT INTO `permissions` VALUES (42, 'newsletter_index', 'Xem thông tin đăng ký', NULL, 'Newsletter', '2021-05-29 16:09:04', '2021-05-29 16:09:04');
INSERT INTO `permissions` VALUES (43, 'newsletter_delete', 'Xóa đăng ký', NULL, 'Newsletter', '2021-05-29 16:09:16', '2021-05-29 16:09:16');
INSERT INTO `permissions` VALUES (44, 'transaction_index', 'Xem thông tin đặt hàng', NULL, 'Transaction', '2021-05-31 11:09:50', '2021-05-31 11:09:50');
INSERT INTO `permissions` VALUES (45, 'transaction_delete', 'Xóa thông tin đặt hàng', NULL, 'Transaction', '2021-05-31 11:10:08', '2021-05-31 11:10:08');
INSERT INTO `permissions` VALUES (46, 'group_index', 'Xem danh sách thư viện', NULL, 'Gallery', '2021-06-13 18:06:53', '2021-06-13 18:06:53');
INSERT INTO `permissions` VALUES (47, 'gallery_index', 'Xem danh sách hình ảnh', NULL, 'Gallery', '2021-06-13 18:07:14', '2021-06-13 18:07:14');
INSERT INTO `permissions` VALUES (48, 'gallery_create', 'Thêm mới hình ảnh', NULL, 'Gallery', '2021-06-13 18:07:28', '2021-06-13 18:07:28');
INSERT INTO `permissions` VALUES (49, 'gallery_edit', 'Sửa hình ảnh', NULL, 'Gallery', '2021-06-13 18:07:43', '2021-06-13 18:07:43');
INSERT INTO `permissions` VALUES (50, 'gallery_delete', 'Xóa hình ảnh', NULL, 'Gallery', '2021-06-13 18:07:59', '2021-06-13 18:07:59');

-- ----------------------------
-- Table structure for post
-- ----------------------------
DROP TABLE IF EXISTS `post`;
CREATE TABLE `post`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `category` int(11) NULL DEFAULT 0,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `thumbnail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `meta_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `meta_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `meta_keyword` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `display` int(11) NOT NULL DEFAULT 0,
  `count_view` int(11) NOT NULL DEFAULT 0,
  `tags` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `user_post` int(11) NOT NULL DEFAULT 0,
  `user_edit` int(11) NOT NULL DEFAULT 0,
  `status` enum('active','disable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `post_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'blog',
  `lang_code` enum('vn','en') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'vn',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of post
-- ----------------------------
INSERT INTO `post` VALUES (1, 'TPHCM: Thêm 2 con của bệnh nhân bán quán ăn dương tính với SARS-CoV-2', 1, 'tphcm-them-2-con-cua-benh-nhan-ban-quan-an-duong-tinh-voi-sars-cov-2', 'Kết quả xét nghiệm những người tiếp xúc với nữ bệnh nhân bán quán ăn tại Quận 3 cho thấy 2 con của bệnh nhân đã dương tính với SARS-CoV-2.', '<p>Th&ocirc;ng&nbsp;tin nhanh&nbsp;từ Trung t&acirc;m Kiểm so&aacute;t Bệnh tật TPHCM l&uacute;c 14h ng&agrave;y 20/5 cho biết,&nbsp; vừa x&aacute;c định th&ecirc;m 2 ca bệnh dương t&iacute;nh với SARS-CoV-2. Theo đ&oacute;, sau khi ph&aacute;t hiện ca bệnh l&agrave; nữ bệnh nh&acirc;n từng đến kh&aacute;m tại Ph&ograve;ng kh&aacute;m Đa khoa H&ograve;a Hảo, cơ quan chức năng khẩn trương điều tra v&agrave; x&aacute;c định 15 trường hợp tiếp x&uacute;c gần tại nơi ở của bệnh nh&acirc;n.</p>\r\n\r\n<p>Ngay lập tức, những người tiếp x&uacute;c gần được chuyển đến khu c&aacute;ch ly tập trung, lấy mẫu x&eacute;t nghiệm. Kết quả x&eacute;t nghiệm khẩn 15 trường hợp đ&atilde; x&aacute;c định th&ecirc;m 2 trường hợp dương t&iacute;nh l&agrave; 2 người con, sống c&ugrave;ng nh&agrave; của bệnh nh&acirc;n.</p>', '2021/05/20/z-24991664848095-d-5-bc-9-b-5-e-68-a-57810539-bd-3-ed-31-a-448-d-1621495410702.jpg', 'thẻ description', 'thẻ meta', NULL, 0, 0, 'test từ khóa', 14, 0, 'active', 'blog', 'vn', '2021-05-20 15:50:08', '2021-05-20 16:36:32');
INSERT INTO `post` VALUES (2, 'Chiến hạm Mỹ áp sát quần đảo Hoàng Sa', 1, 'chien-ham-my-ap-sat-quan-dao-hoang-sa', 'Tàu khu trục USS Curtis Wilbur của Mỹ đã di chuyển áp sát quần đảo Hoàng Sa thuộc chủ quyền của Việt Nam, nhằm thách thức các yêu sách phi pháp của Trung Quốc.', '<p>Hạm đội 7 của Hải qu&acirc;n Mỹ ng&agrave;y 20/5 cho biết, t&agrave;u khu trục t&ecirc;n lửa dẫn đường USS Curtis Wilbur đ&atilde; thực hiện nhiệm vụ tuần tra để &quot;khẳng định c&aacute;c quyền v&agrave; tự do h&agrave;ng hải trong khu vực gần quần đảo Ho&agrave;ng Sa, ph&ugrave; hợp với luật ph&aacute;p quốc tế&quot;.</p>\r\n\r\n<p>Quần đảo Ho&agrave;ng Sa thuộc chủ quyền của Việt Nam bị Trung Quốc chiếm đ&oacute;ng tr&aacute;i ph&eacute;p v&agrave; cải tạo bất hợp ph&aacute;p.</p>\r\n\r\n<p>Trung Quốc x&aacute;c nhận t&agrave;u khu trục USS Curtis Wilbur của Mỹ đ&atilde; di chuyển v&agrave;o v&ugrave;ng biển gần quần đảo Ho&agrave;ng Sa.&nbsp;Bộ Chỉ huy Chiến khu ph&iacute;a Nam của qu&acirc;n đội Trung Quốc đ&atilde; điều t&agrave;u v&agrave; m&aacute;y bay b&aacute;m theo t&agrave;u khu trục của Mỹ.</p>\r\n\r\n<p>Trung Quốc ngang nhi&ecirc;n đưa ra y&ecirc;u s&aacute;ch chủ quyền phi l&yacute; với hầu hết Biển Đ&ocirc;ng th&ocirc;ng qua c&aacute;i gọi l&agrave; &quot;đường ch&iacute;n đoạn&quot; - kh&aacute;i niệm kh&ocirc;ng được cộng đồng quốc tế c&ocirc;ng nhận. Th&aacute;ng 7 năm ngo&aacute;i, Bộ Ngoại giao Mỹ đ&atilde; ra th&ocirc;ng c&aacute;o mạnh mẽ b&aacute;c bỏ c&aacute;c đ&ograve;i hỏi chủ quyền của Trung Quốc ở Biển Đ&ocirc;ng, nhấn mạnh c&aacute;c y&ecirc;u s&aacute;ch n&agrave;y l&agrave; &quot;ho&agrave;n to&agrave;n bất hợp ph&aacute;p&quot;.</p>', '2021/05/20/curtis-wilbur-1621498320565.jpg', 'Tàu khu trục USS Curtis Wilbur của Mỹ đã di chuyển áp sát quần đảo Hoàng Sa thuộc chủ quyền của Việt Nam, nhằm thách thức các yêu sách phi pháp của Trung Quốc.', 'Chiến hạm Mỹ áp sát quần đảo Hoàng Sa', NULL, 0, 0, NULL, 14, 0, 'active', 'blog', 'vn', '2021-05-20 16:02:04', '2021-05-20 17:01:54');
INSERT INTO `post` VALUES (3, 'ba-yeu-to-then-chot-tao-dung-mo-hinh-san-xuat-ca-phe-ben-vung', 0, 'ba-yeu-to-then-chot-tao-dung-mo-hinh-san-xuat-ca-phe-ben-vung', NULL, NULL, NULL, NULL, 'ba-yeu-to-then-chot-tao-dung-mo-hinh-san-xuat-ca-phe-ben-vung', NULL, 0, 0, NULL, 14, 14, 'disable', 'blog', 'vn', '2021-05-20 16:15:17', '2021-05-21 17:04:49');
INSERT INTO `post` VALUES (4, 'Giới thiệu về Liên Kết Số', 0, 'gioi-thieu-ve-lien-ket-so', 'Chúng tôi làm website không chỉ đơn giản là làm ra một sản phẩm, mà đó còn là một giải pháp trong việc kết nối doanh nghiệp với khách hàng, bởi vậy chúng tôi sẽ đồng hành cùng bạn trên con đường phát triển sau này nhé', '<p>Ch&uacute;ng t&ocirc;i l&agrave;m website kh&ocirc;ng chỉ đơn giản l&agrave; l&agrave;m ra một sản phẩm, m&agrave; đ&oacute; c&ograve;n l&agrave; một giải ph&aacute;p trong việc kết nối doanh nghiệp với kh&aacute;ch h&agrave;ng, bởi vậy ch&uacute;ng t&ocirc;i sẽ đồng h&agrave;nh c&ugrave;ng bạn tr&ecirc;n con đường ph&aacute;t triển sau n&agrave;y.</p>\r\n\r\n<p>Trong thế giới kỹ thuật số ng&agrave;y nay, trang web của bạn l&agrave; nơi tương t&aacute;c đầu ti&ecirc;n giữa người ti&ecirc;u d&ugrave;ng c&oacute; với doanh nghiệp của bạn. Đ&oacute; l&agrave; l&yacute; do tại sao gần 95% ấn tượng đầu ti&ecirc;n của người d&ugrave;ng li&ecirc;n quan đến thiết kế web . Đ&oacute; cũng l&agrave; l&yacute; do tại sao c&aacute;c dịch vụ thiết kế web c&oacute; thể c&oacute; t&aacute;c động to lớn đến lợi nhuận của c&ocirc;ng ty bạn. Ch&iacute;nh v&igrave; vậy, việc c&oacute; một trang web hấp dẫn cả về mặt h&igrave;nh ảnh, bố cục v&agrave; nội dung l&agrave; điều đầu ti&ecirc;n tạo cho kh&aacute;ch h&agrave;ng của bạn cảm gi&aacute;c muốn được l&agrave;m việc với doanh nghiệp. Với hơn 6 năm kinh nghiệm, ch&uacute;ng t&ocirc;i tự tin c&oacute; thể thiết kế một trang web t&ugrave;y chỉnh th&uacute;c đẩy doanh số b&aacute;n h&agrave;ng cho doanh nghiệp của bạn.</p>', NULL, 'Chúng tôi làm website không chỉ đơn giản là làm ra một sản phẩm, mà đó còn là một giải pháp trong việc kết nối doanh nghiệp với khách hàng, bởi vậy chúng tôi sẽ đồng hành cùng bạn trên con đường phát triển sau này.', 'Giới thiệu về Liên Kết Số', NULL, 0, 2, NULL, 14, 14, 'active', 'page', 'vn', '2021-05-23 11:27:23', '2021-06-07 14:44:56');
INSERT INTO `post` VALUES (5, 'Dịch vụ thiết kế website', 0, 'dich-vu-thiet-ke-website', 'Trong thế giới kỹ thuật số ngày nay, trang web của bạn là nơi tương tác đầu tiên giữa người tiêu dùng có với doanh nghiệp của bạn. Đó là lý do tại sao gần 95% ấn tượng đầu tiên của người dùng liên quan đến thiết kế web', '<p>Trong thế giới kỹ thuật số ng&agrave;y nay, trang web của bạn l&agrave; nơi tương t&aacute;c đầu ti&ecirc;n giữa người ti&ecirc;u d&ugrave;ng c&oacute; với doanh nghiệp của bạn. Đ&oacute; l&agrave; l&yacute; do tại sao gần 95% ấn tượng đầu ti&ecirc;n của người d&ugrave;ng li&ecirc;n quan đến thiết kế web. Đ&oacute; cũng l&agrave; l&yacute; do tại sao c&aacute;c dịch vụ thiết kế web c&oacute; thể c&oacute; t&aacute;c động to lớn đến lợi nhuận của c&ocirc;ng ty bạn. Ch&iacute;nh v&igrave; vậy, việc c&oacute; một trang web hấp dẫn cả về mặt h&igrave;nh ảnh, bố cục v&agrave; nội dung l&agrave; điều đầu ti&ecirc;n tạo cho kh&aacute;ch h&agrave;ng của bạn cảm gi&aacute;c muốn được l&agrave;m việc với doanh nghiệp. Với hơn 6 năm kinh nghiệm, ch&uacute;ng t&ocirc;i tự tin c&oacute; thể thiết kế một trang web t&ugrave;y chỉnh th&uacute;c đẩy doanh số b&aacute;n h&agrave;ng cho doanh nghiệp của bạn.</p>', NULL, 'Trong thế giới kỹ thuật số ngày nay, trang web của bạn là nơi tương tác đầu tiên giữa người tiêu dùng có với doanh nghiệp của bạn. Đó là lý do tại sao gần 95% ấn tượng đầu tiên của người dùng liên quan đến thiết kế web', 'Dịch vụ thiết kế website', NULL, 0, 0, NULL, 14, 0, 'active', 'page', 'vn', '2021-05-23 11:39:38', '2021-05-23 17:07:39');
INSERT INTO `post` VALUES (6, 'NBA playoffs: Stars show out with big performances during exciting first day of games', 1, 'nba-playoffs-stars-show-out-with-big-performances-during-exciting-first-day-of-games', 'The NBA playoffs are finally upon us, and some of the league\'s biggest stars showed out during the first day of games. Fans got a Saturday full of highlights and huge performances as the best put on a show in four series openers.', '<h2><strong>Blazers 123, Nuggets 109</strong></h2>\r\n\r\n<p>The first game of the series brought the first appearance of Dame Time in the playoffs, with Damian Lillard&nbsp;scoring 20 of his 34 points in the second half&nbsp;as the Blazers grabbed home-court advantage with the win. Lillard added 13 assists, and Portland shot 19-of-40 (47.5%) from 3-point range. Nuggets star Nikola Jokic,&nbsp;the MVP frontrunner, matched Lillard with 34 and added 16 rebounds. Michael Porter Jr. had 25 points, but he shot just 1-of-10 from 3-point range as Denver was 11-of-36 (30.6%) from outside. Jamal Murray, out for the season with a knee injury,&nbsp;was on the sideline to offer encouragement, but the Nuggets missed his scoring and playmaking.</p>\r\n\r\n<p><strong>State of the series:</strong>&nbsp;Blazers lead 1-0.&nbsp;</p>', '2021/05/23/0a0de53a-cb58-4681-8811-135c7eead0f2-2021-05-22_NBA9.jpg', 'The NBA playoffs are finally upon us, and some of the league\'s biggest stars showed out during the first day of games. Fans got a Saturday full of highlights and huge performances as the best put on a show in four series openers.', 'NBA playoffs: Stars show out with big performances during exciting first day of games', NULL, 0, 0, NULL, 14, 14, 'active', 'blog', 'en', '2021-05-23 18:06:33', '2021-05-23 18:06:55');
INSERT INTO `post` VALUES (7, 'Vietnam Partner Search', 0, 'vietnam-partner-search', 'Save time and money by identifying prospects that match your needs without the need to travel.', '<p>Looking for Vietnamese partners / Looking for Vietnamese partners plus virtual referrals<br />\r\nLooking for agents, distributors or other potential strategic partners in Vietnam? We can save you valuable time and money by identifying the right leads for your needs without having to go to market.<br />\r\nProviding services for companies and individuals wishing to invest in importing the best products in Vietnam.</p>\r\n\r\n<p>&nbsp;</p>', NULL, 'Save time and money by identifying prospects that match your needs without the need to travel.', 'Vietnam Partner Search', NULL, 1, 0, NULL, 14, 14, 'active', 'page', 'en', '2021-05-31 16:30:27', '2021-05-31 16:42:04');

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `cat_id` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL DEFAULT 0,
  `price` double NOT NULL DEFAULT 0,
  `disprice` double NOT NULL DEFAULT 0,
  `discount` int(11) NOT NULL DEFAULT 0,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `thumbnail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `meta_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `meta_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `display` tinyint(4) NOT NULL DEFAULT 0,
  `status` enum('active','disable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `user_post` int(11) NOT NULL DEFAULT 0,
  `user_edit` int(11) NOT NULL DEFAULT 0,
  `count_view` int(11) NOT NULL DEFAULT 0,
  `lang_code` enum('vn','en') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'vn',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES (1, 'Kẹo dẻo Trolli Planet Gummi hình Quả địa cầu', 'keo-deo-trolli-planet-gummi-hinh-qua-dia-cau', 2, 1, 29000, 35000, 0, 'Trolli xứng là 1 trong những thương hiệu kẹo dẻo ngon nhất thế giới.', '<p>Loại kẹo dẻo đang l&agrave;m mưa l&agrave;m gi&oacute; tại thị trường H&agrave;n Quốc, v&agrave; đ&oacute; ch&iacute;nh l&agrave;&nbsp;<em><strong>Trolli Planet&nbsp;</strong></em>(Địa cầu). Sản phẩm lu&ocirc;n trong t&igrave;nh trạng ch&aacute;y h&agrave;ng v&igrave; sức hấp dẫn của n&oacute;, được xuất hiện trong hầu hết tất cả c&aacute;c video ASMR của Youtuber H&agrave;n Quốc. Kh&ocirc;ng thể phủ nhận đ&acirc;y l&agrave; loại kẹo qu&aacute; ngon v&agrave; thiết kế qu&aacute; đặc biệt, chắc chắc bạn kh&ocirc;ng thể bỏ qua những loại kẹo dẻo n&agrave;y nếu bạn l&agrave; 1 người s&agrave;nh ăn.</p>\r\n\r\n<p>Để n&oacute;i về những thương hiệu t&ecirc;n tuổi trong ph&acirc;n kh&uacute;c kẹo dẻo, th&igrave; Trolli chắc chắn sẽ l&agrave; c&aacute;i t&ecirc;n được c&aacute;c t&iacute;n đồ ăn uống tr&ecirc;n thế giới kể t&ecirc;n. B&ecirc;n cạnh những thương hiệu Haribo, LifeSavers, Albanes, Black Forest, th&igrave; Trolli l&agrave; 1 c&aacute;i t&ecirc;n kh&aacute; nổi bật, mặc d&ugrave; thương hiệu n&agrave;y được khai sinh tại Đức. Nhưng kh&ocirc;ng phải v&igrave; thế m&agrave; Trolli thua k&eacute;m c&aacute;c thương hiệu kh&aacute;c, với sự tinh tế của người Đức th&igrave; cho đến nay kẹo dẻo Trolli đ&atilde; sản sinh ra rất nhiều mẫu m&atilde; kẹo dẻo v&agrave; m&ugrave;i vị kh&aacute;c nhau.</p>', '2021/05/24/trolli.png', 'Kẹo dẻo Trolli Planet Gummi hình Quả địa cầu', 'Trolli xứng là 1 trong những thương hiệu kẹo dẻo ngon nhất thế giới.', 1, 'active', 14, 14, 0, 'vn', '2021-05-24 15:28:08', '2021-05-28 15:55:07');
INSERT INTO `product` VALUES (2, 'Nước mát gan Hovenia Dulcis Gold', 'nuoc-mat-gan-hovenia-dulcis-gold', 14, 1, 590000, 690000, 0, 'Hộp lớn: 6 hộp nhỏ (100 ml * 5 gói/hộp); 5 hộp lớn/thùng , Sản phẩm được đóng gói tiện lợi, 100ml/gói thích hợp cho 1 lần uống', '<ul>\r\n	<li>Với vị ngọt dễ uống, t&iacute;nh m&aacute;t;&nbsp;Nước uống bổ gan, giải rượu&nbsp;gi&uacute;p bổ gan thanh lọc giải độc gan, phục hồi gan hư tổn.</li>\r\n	<li>Bổ gan, tăng cường chức năng gan. Hỗ trợ điều trị trong trường hợp gan bị suy yếu hay mắc bệnh, bệnh nh&acirc;n thời k&igrave; dưỡng bệnh suy nhược cơ thể.</li>\r\n	<li>Bồi bổ cơ thể, thanh nhiệt giải độc cơ thể, đ&agrave;o thải c&aacute;c chất độc hại trong m&aacute;u.</li>\r\n	<li>Nước uống bổ gan,giải rượu Hovenia&nbsp;c&oacute; t&aacute;c dụng chuyển h&oacute;a cồn th&agrave;nh nước. Chống ngộ độc rượu, giảm c&aacute;c triệu chứng sau uống rượu như buồn n&ocirc;n, đau đầu, ợ n&oacute;ng.</li>\r\n	<li>Nhuận tr&agrave;ng l&agrave;m hết mụn nhọt, trứng c&aacute;, l&agrave;m đẹp da phụ nữ bằng c&aacute;ch thải trừ chất b&atilde; nhờn, chống l&atilde;o h&oacute;a sớm ở nam giới do lạm dụng hoặc thường xuy&ecirc;n d&ugrave;ng đồ uống c&oacute; cồn\r\n	<p>Xuất xứ:&nbsp;C&ocirc;ng ty TNHH KOREA GINSENG BIO SCIECE VIỆT NAM.</p>\r\n\r\n	<p>&nbsp; &nbsp; Quy c&aacute;ch đ&oacute;ng g&oacute;i: {6 hộp nhỏ (100ml * 5 g&oacute;i/ hộp) - 30 g&oacute;i}/hộp; 5 hộp/th&ugrave;ng</p>\r\n\r\n	<p>&nbsp; &nbsp; Hạn sử dụng&nbsp;: 3 năm kể từ ng&agrave;y sản xuất (xem tr&ecirc;n bao b&igrave; sản phẩm).</p>\r\n\r\n	<p><em>&nbsp; &nbsp; Sản phẩm kh&ocirc;ng phải l&agrave; thuốc, kh&ocirc;ng phải l&agrave; thuốc chữa bệnh.</em></p>\r\n	</li>\r\n</ul>', '2021/05/24/mát gan.png', 'Nước mát gan Hovenia Dulcis Gold', 'Hộp lớn: 6 hộp nhỏ (100 ml * 5 gói/hộp); 5 hộp lớn/thùng , Sản phẩm được đóng gói tiện lợi, 100ml/gói thích hợp cho 1 lần uống', 0, 'active', 14, 14, 0, 'vn', '2021-05-24 15:33:53', '2021-05-28 16:36:51');
INSERT INTO `product` VALUES (3, 'Trứng nướng Hàn Quốc vỉ 2 quả', 'trung-nuong-han-quoc-vi-2-qua', 2, 4, 19000, 25000, 0, 'Trứng nướng theo công nghệ Hàn Quốc, đảm bảo vệ sinh an toàn thực phẩm', '<ul>\r\n	<li>Miễn ph&iacute; vận chuyển đơn h&agrave;ng từ 300.000đ, b&aacute;n k&iacute;nh 5km t&iacute;nh từ si&ecirc;u thị</li>\r\n	<li>Nh&agrave; cung cấp ch&iacute;nh h&atilde;ng, an to&agrave;n vệ sinh thực phẩm</li>\r\n	<li>Hỗ trợ đặt h&agrave;ng từ 8h -22h</li>\r\n</ul>', '2021/05/25/1621914820-trung-nuong-pmg.png', 'Trứng nướng Hàn Quốc vỉ 2 quả', 'Trứng nướng theo công nghệ Hàn Quốc, đảm bảo vệ sinh an toàn thực phẩm', 0, 'active', 14, 14, 0, 'vn', '2021-05-25 10:05:57', '2021-05-26 13:17:47');
INSERT INTO `product` VALUES (4, 'Bánh quy Haitai bòng chày nhân socola 46g', 'banh-quy-haitai-bong-chay-nhan-socola-46g', 14, 1, 31000, 50000, 0, 'Bánh snack Home Run Ball có vị giòn tan của lớp bánh cùng vị sô cô la mới lạ hấp dẫn.', '<p>Th&agrave;nh phần: Bột ca cao 4%, đường trắng, kem b&eacute;o thực vật, bột sữa, bơ lạc (bơ đậu phộng), trứng g&agrave;, magarin, bột m&igrave;, bột bắp, muối, hương vani tự nhi&ecirc;n, m&agrave;u thực phẩm (Riboflavin - E 101) C&ocirc;ng dụng: D&ugrave;ng l&agrave;m đồ ăn vặt Đặc điểm nổi bật của b&aacute;nh snack vi&ecirc;n chocolate home run ball haitai B&aacute;nh snack Home Run Ball được sản xuất từ nguồn nguy&ecirc;n liệu qua chọn lọc kĩ lưỡng, c&ocirc;ng thức chế biến đặc biệt tạo n&ecirc;n hương vị thơm ngon. Sản phẩm c&oacute; vị gi&ograve;n tan của lớp b&aacute;nh b&ecirc;n ngo&agrave;i c&ugrave;ng vị s&ocirc; c&ocirc; la b&ecirc;n trong mới lạ hấp dẫn. Sản phẩm được sản xuất theo c&ocirc;ng nghệ hiện đại, nguy&ecirc;n liệu được chọn lựa kỹ lưỡng, kh&ocirc;ng chứa h&oacute;a chất, chất bảo quản độc hại, kh&ocirc;ng chỉ cung cấp c&aacute;c kho&aacute;ng chất v&agrave; vitamin thiết yếu cho cơ thể m&agrave; c&ograve;n đảm bảo an to&agrave;n cho sức khỏe. Lớp vỏ b&aacute;nh gi&ograve;n rụm kết hợp với vị socola ngọt ng&agrave;o b&ecirc;n trong mang đến những trải nghiệm về hương vị cực kỳ th&uacute; vị. Đ&oacute;ng g&oacute;i nhỏ gọn, tiện dụng, hương vị thơm ngon hấp dẫn Vệ sinh an to&agrave;n thực phẩm l&agrave; vấn đề h&agrave;ng đầu người ti&ecirc;u d&ugrave;ng quan t&acirc;m. B&aacute;nh snack Home Run Ball Haitai được l&agrave;m từ những nguy&ecirc;n liệu an to&agrave;n, đảm bảo chất lượng cũng như hương vị. Sản phẩm được nhập khẩu ch&iacute;nh h&atilde;ng tại H&agrave;n Quốc. B&aacute;nh được đ&oacute;ng bịch nhỏ gọn, dễ d&agrave;ng mang theo trong những chuyến du lịch, d&atilde; ngoại hoặc th&ecirc;m v&agrave;o c&aacute;c giỏ qu&agrave; biếu, tặng bạn b&egrave;, người th&acirc;n v&agrave;o c&aacute;c dịp đặc biệt.</p>', '2021/05/25/trung-nuong-han-quoc.jpg', 'Bánh quy Haitai bòng chày nhân socola 46g', 'Bánh snack Home Run Ball có vị giòn tan của lớp bánh cùng vị sô cô la mới lạ hấp dẫn.', 0, 'active', 14, 14, 0, 'vn', '2021-05-25 10:21:02', '2021-05-27 13:51:45');
INSERT INTO `product` VALUES (5, 'Kitchen knife holder', 'kitchen-knife-holder', 22, 5, 0, 0, 0, 'Bamboo knife holder is a new environmentally friendly product', '<p>Material 100% bamboo products<br />\r\nColor Natural bamboo color<br />\r\nDimensions Length 23cm x Width 12cm x Height 20cm<br />\r\nMade in Viet Nam</p>\r\n\r\n<p>Bamboo knife holder is a new environmentally friendly product of BAMBO VINA.<br />\r\nThe box is made entirely of natural bamboo covered with a safe paint against termites and mold.<br />\r\nThe sturdy design, 45-degree angled stable base makes it easy to pull the knife in and out, and at this angle, the knife is always kept dry and clean.<br />\r\nThe box with many different compartments is convenient for storing many types of large and small knives to meet the needs of every family.<br />\r\nThe knife holder is an indispensable item in every family to save space and easy to store knives and scissors.</p>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://hmvc.test/upload/2021/05/31/hop-cam-dao-1_1622449541.jpg\" style=\"height:600px; width:600px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://hmvc.test/upload/2021/05/31/hop-cam-dao-2-1_1622449584.jpg\" style=\"height:600px; width:600px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://hmvc.test/upload/2021/05/31/hop-cam-dao-3_1622449604.jpg\" style=\"height:600px; width:600px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://hmvc.test/upload/2021/05/31/hop-cam-dao-5_1622449617.jpg\" style=\"height:600px; width:600px\" /></p>', '2021/05/31/1622449728-hop-cam-dao-3.jpg', 'Kitchen knife holder', 'Bamboo knife holder is a new environmentally friendly product of BAMBO VINA.', 1, 'active', 14, 14, 1, 'en', '2021-05-31 15:28:48', '2021-05-31 18:06:58');
INSERT INTO `product` VALUES (6, 'Rectangular paper box', 'rectangular-paper-box', 22, 5, 0, 0, 0, 'The box is made entirely from natural bamboo to help preserve the paper better, safe for users.', '<p>Material 100% bamboo products<br />\r\nColor Natural bamboo color<br />\r\nDimensions Length 23cm x Width 12cm x Height 9cm<br />\r\nDesigned by BamBoo Vina Production and Trading Co., Ltd<br />\r\nMade in Viet Nam</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://hmvc.test/upload/2021/05/31/hop-dung-giay-to-6_1622450039.jpg\" style=\"height:600px; width:600px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://hmvc.test/upload/2021/05/31/hop-dung-giay-to-4-1 (1)_1622450062.jpg\" style=\"height:600px; width:600px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://hmvc.test/upload/2021/05/31/hop-dung-giay-to-2_1622450075.jpg\" style=\"height:600px; width:600px\" /></p>\r\n\r\n<p>The bamboo rectangular paper box is a new environmentally friendly product of BAMBO VINA.<br />\r\nThe box is made entirely from natural bamboo to help preserve the paper better, safe for users.<br />\r\nThe simple design is convenient for users to open and reassemble when needing to add more paper.<br />\r\nLarge size for the right amount of paper for family activities.<br />\r\nPaper boxes are indispensable items in every home, restaurant, hotel&hellip;.</p>', '2021/05/31/1622450093-hop-dung-giay-to-5.jpg', 'Rectangular paper box', 'The box is made entirely from natural bamboo to help preserve the paper better, safe for users.', 1, 'active', 14, 14, 0, 'en', '2021-05-31 15:34:53', '2021-05-31 15:35:36');
INSERT INTO `product` VALUES (7, 'Bamboo desk with iron legs', 'bamboo-desk-with-iron-legs', 22, 5, 0, 0, 0, 'Beauty from natural bamboo veins with solid foot structure and covered with anti-scratch, anti-mildew paint for convenient storage.', '<p>Material 100% product is made from bamboo<br />\r\nColor Natural bamboo color<br />\r\nDimensions Length 60cm x Width 40cm x Height 25cm<br />\r\nDesigned by BamBoo Vina Production and Trading Co., Ltd<br />\r\nMade in Viet Nam</p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://hmvc.test/upload/2021/05/31/ban-hoc-sinh-tre-chan-sat-3_1622450275.jpg\" style=\"height:600px; width:600px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://hmvc.test/upload/2021/05/31/ban-hoc-sinh-tre-chan-sat-1-2_1622450319.jpg\" style=\"height:600px; width:600px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://hmvc.test/upload/2021/05/31/ban-hoc-sinh-tre-chan-sat-7-2_1622450335.jpg\" style=\"height:600px; width:600px\" /></p>\r\n\r\n<p>Student desk 60x40x25cm is one of the products of BamBo Vina.<br />\r\nBeauty from natural bamboo veins with solid foot structure and covered with anti-scratch, anti-mildew paint for convenient storage.<br />\r\nThe table has an elegant and compact design suitable for a laptop table, a reading table, a coloring table for children, a desk for studying, working indoors or out or in the car....<br />\r\nTable legs designed with stainless steel, easy to use, convenient for opening and folding.<br />\r\nThe table top uses simple but equally delicate bamboo wood, which is convenient for cleaning with a damp cloth.<br />\r\nNeatly designed table is definitely a choice with high mobility, can be folded neatly after use to save space for the family.</p>', '2021/05/31/1622450351-ban-hoc-sinh-tre-chan-sat-3.jpg', 'Bamboo student desk with iron legs', 'Beauty from natural bamboo veins with solid foot structure and covered with anti-scratch, anti-mildew paint for convenient storage.', 1, 'active', 14, 14, 1, 'en', '2021-05-31 15:39:11', '2021-05-31 18:01:46');
INSERT INTO `product` VALUES (8, 'Apple-shaped cutting board', 'apple-shaped-cutting-board', 22, 5, 0, 0, 0, 'Apple-shaped cutting board 30x wide 30x high 2.0cm is a high-class kitchen equipment product from bamboo with antibacterial and anti-odor properties designed, manufactured and distributed by BAMBO VINA.', '<p>Material 100% product is made from bamboo<br />\r\nColor Natural bamboo color<br />\r\nDimensions Length 30cm Width 30cm x Height 2cm<br />\r\nDesigned by BAMBO VINA<br />\r\nMade in Viet Nam</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Apple-shaped cutting board 30x wide 30x high 2.0cm:<br />\r\nApple-shaped cutting board 30x wide 30x high 2.0cm is a high-class kitchen equipment product from bamboo with antibacterial and anti-odor properties designed, manufactured and distributed by BAMBO VINA.<br />\r\nBAMBO VINA&#39;s apple-shaped cutting board 30x wide 30x high 2.0cm is suitable for processing meat, fish, fruits and vegetables.<br />\r\nThe safe organic paint on the surface of the cutting board has an antibacterial effect and protects the surface for long-term use.<br />\r\nUsing bamboo cutting boards will not leave black marks when handling food like ordinary wooden cutting boards..</p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://hmvc.test/upload/2021/05/31/TQT303020-2-1_1622450649.jpg\" style=\"height:600px; width:600px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://hmvc.test/upload/2021/05/31/TQT303020-4-1_1622450669.jpg\" style=\"height:600px; width:600px\" /></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"http://hmvc.test/upload/2021/05/31/TQT303020-7-1_1622450680.jpg\" style=\"height:600px; width:600px\" /></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Note:</strong><br />\r\nDo not soak the cutting board in water for too long (more than 1 hour).<br />\r\nYou should keep the cutting board in a well-ventilated place to quickly dry to avoid mold.<br />\r\nIn case of stains, black, you can use lemon or soda to clean, then wash and dry, then apply vegetable oil to increase the time of use.<br />\r\nDo not wash the bamboo cutting board in the dishwasher (dish).<br />\r\nIt is recommended to change cutting boards after 12 months of use to ensure the health of the family.<br />\r\nEach family needs to have 2 or more cutting boards used to cut raw and cooked food separately to ensure food safety.</p>', '2021/05/31/1622450691-TQT303020-3-1.jpg', 'Apple-shaped cutting board', 'Apple-shaped cutting board 30x wide 30x high 2.0cm is a high-class kitchen equipment product from bamboo with antibacterial and anti-odor properties designed, manufactured and distributed by BAMBO VINA.', 1, 'active', 14, 14, 2, 'en', '2021-05-31 15:44:51', '2021-05-31 17:57:44');

-- ----------------------------
-- Table structure for role_user
-- ----------------------------
DROP TABLE IF EXISTS `role_user`;
CREATE TABLE `role_user`  (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`user_id`, `role_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of role_user
-- ----------------------------
INSERT INTO `role_user` VALUES (10, 1);
INSERT INTO `role_user` VALUES (11, 2);
INSERT INTO `role_user` VALUES (14, 1);

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `roles_name_unique`(`name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO `roles` VALUES (1, 'administrator', 'Administrator', 'Tài khoản quản trị cao cấp', '2021-05-18 14:39:52', '2021-05-18 14:39:52');
INSERT INTO `roles` VALUES (2, 'moderator', 'Moderator', 'Tài khoản thành viên cao cấp', '2021-05-18 14:40:17', '2021-05-18 14:40:17');
INSERT INTO `roles` VALUES (4, 'Poster', 'Post bài blog', 'Cho phép post bài', '2021-05-18 18:40:00', '2021-05-18 18:40:00');

-- ----------------------------
-- Table structure for setting
-- ----------------------------
DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `setting_value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of setting
-- ----------------------------
INSERT INTO `setting` VALUES (1, 'site_name_vn', 'Liên Kết Số', '2021-05-23 15:08:36', '2021-05-23 15:08:36');
INSERT INTO `setting` VALUES (2, 'site_description_vn', 'Chúng tôi làm website không chỉ đơn giản là làm ra một sản phẩm, mà đó còn là một giải pháp trong việc kết nối doanh nghiệp với khách hàng, bởi vậy chúng tôi sẽ đồng hành cùng bạn trên con đường phát triển sau này.', '2021-05-23 15:09:36', '2021-05-23 15:18:07');
INSERT INTO `setting` VALUES (3, 'site_footer_info_vn', '<p>Lorem Ipsum is simply dummy text of printing and type setting industry. Lorem Ipsum been industry standard dummy text ever since.</p>', '2021-05-23 15:09:36', '2021-05-29 13:27:41');
INSERT INTO `setting` VALUES (4, 'site_hotline_vn', '0979823452', '2021-05-23 15:09:36', '2021-05-23 15:16:54');
INSERT INTO `setting` VALUES (5, 'site_address_vn', 'Tầng 6, Số 88 Tô Vĩnh Diện Thanh Xuân, Hà Nội', '2021-05-23 15:09:36', '2021-05-23 15:16:54');
INSERT INTO `setting` VALUES (6, 'site_email_vn', 'info@lienketso.vn', '2021-05-23 15:09:36', '2021-05-23 15:17:27');
INSERT INTO `setting` VALUES (7, 'display', '0', '2021-05-23 15:09:36', '2021-05-23 15:09:36');
INSERT INTO `setting` VALUES (8, 'status', 'active', '2021-05-23 15:09:36', '2021-05-23 15:09:36');
INSERT INTO `setting` VALUES (9, 'site_logo', '2021/06/13/Logo.png', '2021-05-23 15:16:54', '2021-06-13 17:15:53');
INSERT INTO `setting` VALUES (10, 'site_name_en', 'Looking for Vietnamese partners', '2021-05-29 13:25:49', '2021-05-31 14:13:32');
INSERT INTO `setting` VALUES (11, 'site_description_en', 'Website specializing in providing services of connecting and exporting products and services in Vietnam', '2021-05-29 13:25:49', '2021-05-31 14:13:32');
INSERT INTO `setting` VALUES (12, 'site_footer_info_en', '<p>Website specializing in providing services of connecting and exporting products and services in Vietnam</p>', '2021-05-29 13:25:49', '2021-05-31 14:13:32');
INSERT INTO `setting` VALUES (13, 'site_hotline_en', '+84878823452', '2021-05-29 13:25:49', '2021-05-31 14:13:32');
INSERT INTO `setting` VALUES (14, 'site_address_en', '6th floor, No. 88 To Vinh Dien, Thanh Xuan, Hanoi, Vietnam', '2021-05-29 13:25:49', '2021-05-31 14:13:32');
INSERT INTO `setting` VALUES (15, 'site_email_en', 'info@lienketso.vn', '2021-05-29 13:25:49', '2021-05-31 14:13:32');
INSERT INTO `setting` VALUES (16, 'list_number', 'Tháng5( 07 10 19 30 40 45 02 15 33 41 44 45 01 10 22 36 38 45 11 14 22 26 29 04 28 37 38 40 42 03 12 23 29 33 34 13 23 33 37 40 43 03 11 16 20 24 30 09 15 22 27 34 42 01 07 16 24 27 37 10 20 21 27 33 34 03 14 20 22 37 44 07 08 30 35 40 44 ) 03 04 20 21 36 41 08 19 21 28 32 44 13 16 18 22 34 39 03 12 19 27 32 35 07 09 15 23 26 27 08 09 11 28 30 39 11 12 16 18 33 35 03 23 27 32 34 39 03 04 08 17 19 37 13 15 19 25 33 34 05 20 27 30 38 43 01 05 09 16 42 44 Thang4) 02 04 06 36 41 42 23 26 40 41 43 44 02 11 15 18 23 42 07 14 23 26 37 39 08 09 11 31 36 39 05 06 24 34 36 37 06 11 26 28 36 41 01 09 11 32 34 42 05 11 17 34 38 42 05 14 15 19 25 33 04 12 25 28 33 45 09 11 13 21 27 41 01 20 28 37 40 44 04 05 25 28 29 42 11 13 19 27 37 41 02 13 19 33 40 43 06 07 22 24 27 37 12 19 22 23 34 44 03 18 21 22 36 44 03 13 18 21 39 44 08 13 18 19 21 24 01 04 07 15 41 42 02 08 31 32 42 44 07 09 14 23 35 41', NULL, '2021-06-01 18:00:08');

-- ----------------------------
-- Table structure for transaction
-- ----------------------------
DROP TABLE IF EXISTS `transaction`;
CREATE TABLE `transaction`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `company_info` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `nation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `status` enum('active','disable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'disable',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of transaction
-- ----------------------------
INSERT INTO `transaction` VALUES (1, 0, 1, 'Trần Trung Anh', '0906909688', 'anhtt.kci@gmail.com.vn', 'My Company', 'Vietnam', '2508A1 Hòa Bình Green City, CT1505 Minh Khai Vĩnh Tuy, Hai Bà Trưng, Hà Nội', 'I want to become your partner, send me profile and information', 'disable', '2021-05-31 11:28:17', '2021-05-31 11:28:17');
INSERT INTO `transaction` VALUES (2, 0, 4, 'Vũ Văn Hải', '0913099933', 'doanhvhai@gmail.com', 'Công ty TNHH Alo Là có', 'America', 'Số 17, ngõ 100, Nghĩa Dũng, Phúc Xá, Ba Đình', 'Test thôi nhé', 'disable', '2021-05-31 12:17:20', '2021-05-31 12:17:20');
INSERT INTO `transaction` VALUES (3, 0, 4, 'NGUYỄN THỊ TÂM', '0916995658', 'Powdermetall.jsc@gmail.com', 'Công ty TNHH Nhân Hòa', 'Nihon', 'Phòng 401 nhà 114 Phương Liệt, Thanh Xuân, Hà Nội', 'Cần tư vấn và tìm kiếm sản phẩm của công ty', 'disable', '2021-05-31 12:26:10', '2021-05-31 12:26:10');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `full_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `email_verified_at` timestamp(0) NULL DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `thumbnail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `status` enum('active','disable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'disable',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (5, 'adminlksd', 'Powdermetall.jsc@gmail.com', '$2y$10$rvZZ27lXTqA0ZiYbb4f/6efNetND3WtmZMxJitGINh3R4eYfBvCui', 'NGUYỄN THỊ TÂM', NULL, 'Phòng 401 nhà 114 Phương Liệt, Thanh Xuân, Hà Nội', NULL, NULL, NULL, NULL, 'disable', '2021-05-18 11:28:03', '2021-05-18 11:37:19');
INSERT INTO `users` VALUES (6, 'adminf5cvnd', 'anhtt.kcii@gmail.com.vn', '$2y$10$fm5DuCbqhyh5hxwAoWJ0g.Pn6j1dw7vb8sOw3DNXkAfY7hOg4SsZO', 'Trần Trung Anh', NULL, '2508A1 Hòa Bình Green City, CT1505 Minh Khai Vĩnh Tuy, Hai Bà Trưng, Hà Nội', NULL, NULL, NULL, NULL, 'disable', '2021-05-18 11:29:35', '2021-05-18 11:39:46');
INSERT INTO `users` VALUES (7, 'adminlkssss', 'doanhvhaccci@gmail.com', '$2y$10$tFH2VBGDPEQz1bD31vob/OPcZrx3.ej1dgmCHY/2rBdF2miX4pq9O', 'Vũ Văn Hải', NULL, 'Số 17, ngõ 100, Nghĩa Dũng, Phúc Xá, Ba Đình', NULL, NULL, NULL, NULL, 'disable', '2021-05-18 11:42:49', '2021-05-18 11:55:57');
INSERT INTO `users` VALUES (8, 'adminssss', 'doanhvhaissssss@gmail.com', '$2y$10$7dvdAEiHV05wLrKcD5URI.xM5m9QCLz0Wc9fiQ.gfMPu7IBWCfhOC', 'Vũ Văn Hải', NULL, 'Số 17, ngõ 100, Nghĩa Dũng, Phúc Xá, Ba Đình', NULL, NULL, NULL, NULL, 'disable', '2021-05-18 11:58:10', '2021-05-18 11:58:10');
INSERT INTO `users` VALUES (9, 'adminssdas', 'doanhvhaiddd@gmail.com', '$2y$10$micj.Np7rWDHUlEESm7/KeQsNyAHYYoE4SH.ofcZMMLdOi.xVCwfG', 'Vũ Văn Hải', NULL, 'Số 17, ngõ 100, Nghĩa Dũng, Phúc Xá, Ba Đình', NULL, NULL, NULL, NULL, 'disable', '2021-05-18 11:58:53', '2021-05-19 10:52:50');
INSERT INTO `users` VALUES (10, 'adminf5cvnsdas', 'doanhvhaissda@gmail.com', '$2y$10$Y2VUlUaW21o5pcJ3ai6J2.rhIeYLWBr4MLf1rNm7Q/3k3dqxWhXMa', 'Vũ Văn Hải', NULL, 'Số 17, ngõ 100, Nghĩa Dũng, Phúc Xá, Ba Đình', NULL, NULL, NULL, '2021/05/18/pic1.jpg', 'disable', '2021-05-18 12:00:43', '2021-05-18 12:44:32');
INSERT INTO `users` VALUES (11, 'tranvanan', 'tranvanan@gmail.com', '$2y$10$Y2dDRztI4BMxPsOFmcjLjOASiqB2pRbYiHdZb3yqvhrrHiGcJ4s3e', 'Trần Văn An', '0979823452', 'Số 36, ngõ 86, phố Hào Nam, phường Ô Chợ Dừa, Quận Đống Đa, Thành Phố Hà Nội', NULL, NULL, NULL, NULL, 'active', '2021-05-19 12:38:50', '2021-05-19 12:41:14');
INSERT INTO `users` VALUES (14, 'wiseman', 'thanhan1507@gmail.com', '$2y$10$.X6s5cxrSEULj9WY76r8Z.CeMHblzeSS9QIG57IOp4fhCdW/CGEQu', 'Nguyễn Thành An', '0979823452', 'Hà Nội', NULL, NULL, NULL, NULL, 'active', '2021-05-20 09:42:36', '2021-05-20 09:42:36');

SET FOREIGN_KEY_CHECKS = 1;
